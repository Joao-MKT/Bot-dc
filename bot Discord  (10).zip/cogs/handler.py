import discord
from discord.ext import commands
import time

class CommandHandler(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # 🧠 mensagens
    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        prefix = "v!"

        # 💀 apagar qualquer comando
        if message.content.startswith(prefix):
            try:
                await message.delete()
            except:
                pass

        # 🤖 se mencionar o bot
        if self.bot.user in message.mentions:

            uptime = int(time.time() - self.bot.start_time)
            ping = round(self.bot.latency * 1000)

            view = discord.ui.LayoutView()

            container = discord.ui.Container(
                discord.ui.TextDisplay(content="🤖 Bot online"),
                discord.ui.TextDisplay(content=f"📡 {ping}ms | ⏱️ {uptime}s")
            )

            view.add_item(container)

            msg = await message.channel.send(view=view)

            # 🧹 apaga depois de 10s
            await msg.delete(delay=10)

        await self.bot.process_commands(message)

    # ❌ comando inválido
    @commands.Cog.listener()
    async def on_command_error(self, ctx, error):

        if isinstance(error, commands.CommandNotFound):

            view = discord.ui.LayoutView()

            container = discord.ui.Container(
                discord.ui.TextDisplay(content="❌ Comando não existe")
            )

            view.add_item(container)

            msg = await ctx.send(view=view)

            await msg.delete(delay=3)

async def setup(bot):
    await bot.add_cog(CommandHandler(bot))