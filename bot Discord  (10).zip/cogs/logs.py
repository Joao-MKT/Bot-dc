import discord
from discord.ext import commands
import os
from dotenv import load_dotenv

load_dotenv()

LOG_MSG = int(os.getenv("LOG_MSG"))
LOG_CALL = int(os.getenv("LOG_CALL"))
LOG_MEMBER = int(os.getenv("LOG_MEMBER"))
LOG_PUNISH = int(os.getenv("LOG_PUNISH"))

class Logs(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def send_log(self, canal_id, textos):
        canal = self.bot.get_channel(canal_id)
        if not canal:
            return

        view = discord.ui.LayoutView()

        container = discord.ui.Container(
            discord.ui.TextDisplay(content=textos[0]),
            discord.ui.Separator()
        )

        for txt in textos[1:]:
            container.add_item(discord.ui.TextDisplay(content=txt))

        view.add_item(container)

        await canal.send(view=view)

    async def get_executor(self, guild, action, target_id):
        async for entry in guild.audit_logs(limit=5, action=action):
            if entry.target.id == target_id:
                return entry.user
        return None

    # 🗑️ mensagem deletada
    @commands.Cog.listener()
    async def on_message_delete(self, message):
        if message.author.bot or not message.guild:
            return

        executor = await self.get_executor(
            message.guild,
            discord.AuditLogAction.message_delete,
            message.author.id
        )

        await self.send_log(LOG_MSG, [
            "# 🗑️ Mensagem deletada",
            f"👤 Autor: {message.author}",
            f"🛠️ Por: {executor or 'Próprio usuário'}",
            f"📄 {message.content or 'Sem texto'}",
            f"📍 {message.channel.mention}"
        ])

    # ✏️ editada
    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        if before.author.bot:
            return

        await self.send_log(LOG_MSG, [
            "# ✏️ Mensagem editada",
            f"👤 {before.author}",
            f"Antes: {before.content}",
            f"Depois: {after.content}"
        ])

    # 👥 entrou
    @commands.Cog.listener()
    async def on_member_join(self, member):
        await self.send_log(LOG_MEMBER, [
            "# ➕ Entrou",
            f"👤 {member}",
            f"🆔 {member.id}"
        ])

    # 👥 saiu / kick
    @commands.Cog.listener()
    async def on_member_remove(self, member):
        executor = await self.get_executor(
            member.guild,
            discord.AuditLogAction.kick,
            member.id
        )

        await self.send_log(LOG_MEMBER, [
            "# ➖ Saiu",
            f"👤 {member}",
            f"👢 {executor or 'Saiu sozinho'}"
        ])

    # 🔊 call
    @commands.Cog.listener()
    async def on_voice_state_update(self, member, before, after):
        if before.channel != after.channel:
            if after.channel:
                await self.send_log(LOG_CALL, [
                    "# 🔊 Entrou na call",
                    f"👤 {member}",
                    f"📍 {after.channel.name}"
                ])
            elif before.channel:
                await self.send_log(LOG_CALL, [
                    "# 🔇 Saiu da call",
                    f"👤 {member}",
                    f"📍 {before.channel.name}"
                ])

    # 🔨 ban
    @commands.Cog.listener()
    async def on_member_ban(self, guild, user):
        executor = await self.get_executor(
            guild,
            discord.AuditLogAction.ban,
            user.id
        )

        await self.send_log(LOG_PUNISH, [
            "# 🔨 Ban",
            f"👤 {user}",
            f"🛠️ {executor or 'Desconhecido'}"
        ])

    # 🔇 mute
    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if before.timed_out_until != after.timed_out_until:

            executor = await self.get_executor(
                after.guild,
                discord.AuditLogAction.member_update,
                after.id
            )

            if after.timed_out_until:
                await self.send_log(LOG_PUNISH, [
                    "# 🔇 Mutado",
                    f"👤 {after}",
                    f"🛠️ {executor or 'Desconhecido'}",
                    f"⏳ {after.timed_out_until}"
                ])
            else:
                await self.send_log(LOG_PUNISH, [
                    "# 🔊 Desmutado",
                    f"👤 {after}",
                    f"🛠️ {executor or 'Desconhecido'}"
                ])

async def setup(bot):
    await bot.add_cog(Logs(bot))