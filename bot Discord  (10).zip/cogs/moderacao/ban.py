import discord
from discord.ext import commands

class Ban(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, member: discord.Member, *, motivo="Sem motivo"):
        await member.ban(reason=motivo)

        view = discord.ui.LayoutView()
        container = discord.ui.Container(
            discord.ui.TextDisplay(content="🔨 Banido"),
            discord.ui.TextDisplay(content=f"{member}")
        )
        view.add_item(container)

        msg = await ctx.send(view=view)
        await msg.delete(delay=5)

async def setup(bot):
    await bot.add_cog(Ban(bot))