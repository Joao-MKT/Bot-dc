import discord
from discord.ext import commands

class Clear(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    @commands.has_permissions(manage_messages=True)
    async def clear(self, ctx, quantidade: int):
        await ctx.channel.purge(limit=quantidade)

        view = discord.ui.LayoutView()
        container = discord.ui.Container(
            discord.ui.TextDisplay(content=f"🧹 {quantidade} mensagens apagadas")
        )
        view.add_item(container)

        msg = await ctx.send(view=view)
        await msg.delete(delay=5)

async def setup(bot):
    await bot.add_cog(Clear(bot)) 