import discord
from discord.ext import commands

class Kick(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, member: discord.Member, *, motivo="Sem motivo"):
        await member.kick(reason=motivo)

        view = discord.ui.LayoutView()
        container = discord.ui.Container(
            discord.ui.TextDisplay(content="👢 Expulso"),
            discord.ui.TextDisplay(content=f"{member}")
        )
        view.add_item(container)

        msg = await ctx.send(view=view)
        await msg.delete(delay=5)

async def setup(bot):
    await bot.add_cog(Kick(bot))