import discord
from discord.ext import commands
from datetime import timedelta

class Mute(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    @commands.has_permissions(moderate_members=True)
    async def mute(self, ctx, member: discord.Member, tempo: int):
        await member.timeout(timedelta(minutes=tempo))

        view = discord.ui.LayoutView()
        container = discord.ui.Container(
            discord.ui.TextDisplay(content="🔇 Mutado"),
            discord.ui.TextDisplay(content=f"{member} ({tempo}m)")
        )
        view.add_item(container)

        msg = await ctx.send(view=view)
        await msg.delete(delay=5)

async def setup(bot):
    await bot.add_cog(Mute(bot))