import discord
from discord.ext import commands

class Nuke(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    @commands.has_permissions(manage_channels=True)
    async def nuke(self, ctx):
        canal = ctx.channel

        novo = await canal.clone()
        await canal.delete()

        await novo.send("💥 Canal resetado")

async def setup(bot):
    await bot.add_cog(Nuke(bot))