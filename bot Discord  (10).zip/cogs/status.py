import discord
from discord.ext import commands
import time
import os
from dotenv import load_dotenv

# 🔐 carregar .env
load_dotenv()
CANAL_ID = int(os.getenv("CANAL_STATUS"))

class Status(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self):
        print("📊 Status ativo!")

        canal = self.bot.get_channel(CANAL_ID)
        if not canal:
            print("❌ Canal não encontrado")
            return

        uptime = int(time.time() - self.bot.start_time)

        horas = uptime // 3600
        minutos = (uptime % 3600) // 60
        segundos = uptime % 60

        ping = round(self.bot.latency * 1000)

        view = discord.ui.LayoutView()

        container = discord.ui.Container(
            discord.ui.TextDisplay(content="# 🤖 STATUS DO BOT"),
            discord.ui.Separator(),

            discord.ui.TextDisplay(content=f"📡 Ping: {ping}ms"),
            discord.ui.TextDisplay(content=f"⏱️ Uptime: {horas}h {minutos}m {segundos}s"),
            discord.ui.TextDisplay(content=f"📦 Cogs: {len(self.bot.cogs)}"),
            discord.ui.TextDisplay(content=f"⚙️ Comandos: {len(self.bot.commands)}"),
            discord.ui.TextDisplay(content=f"📁 Arquivos: {', '.join(os.listdir('./cogs'))}"),

            discord.ui.Separator(),
            discord.ui.TextDisplay(content="✅ Online e estável")
        )

        view.add_item(container)

        try:
            await canal.send(view=view)
            print("✅ Painel enviado")
        except Exception as e:
            print(f"❌ Erro ao enviar painel: {e}")

async def setup(bot):
    await bot.add_cog(Status(bot))