import discord
from discord.ext import commands
import time

class Utils(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # 📡 PING
    @commands.command(name="ping")
    async def ping(self, ctx):
        ping = round(self.bot.latency * 1000)

        view = discord.ui.LayoutView()

        container = discord.ui.Container(
            discord.ui.TextDisplay(content=f"📡 {ping}ms")
        )

        view.add_item(container)

        msg = await ctx.send(view=view)
        await msg.delete(delay=5)

    # 📖 HELP
    @commands.command(name="help")
    async def help(self, ctx):

        comandos = [cmd.name for cmd in self.bot.commands]

        view = discord.ui.LayoutView()

        container = discord.ui.Container(
            discord.ui.TextDisplay(content="📖 Comandos"),
            discord.ui.Separator(),
            discord.ui.TextDisplay(content=" | ".join(comandos))
        )

        view.add_item(container)

        msg = await ctx.send(view=view)
        await msg.delete(delay=10)

    # 🤖 INFO (extra)
    @commands.command(name="info")
    async def info(self, ctx):

        uptime = int(time.time() - self.bot.start_time)
        ping = round(self.bot.latency * 1000)

        view = discord.ui.LayoutView()

        container = discord.ui.Container(
            discord.ui.TextDisplay(content="🤖 Bot"),
            discord.ui.Separator(),
            discord.ui.TextDisplay(content=f"📡 {ping}ms"),
            discord.ui.TextDisplay(content=f"⏱️ {uptime}s"),
            discord.ui.TextDisplay(content=f"📦 {len(self.bot.commands)} cmds")
        )

        view.add_item(container)

        msg = await ctx.send(view=view)
        await msg.delete(delay=10)

async def setup(bot):
    await bot.add_cog(Utils(bot))