import discord
from discord.ext import commands
import os
import asyncio
import time
from dotenv import load_dotenv

# 🔐 carregar .env
load_dotenv()
TOKEN = os.getenv("TOKEN")

# ⚙️ intents
intents = discord.Intents.all()

# 🤖 bot
bot = commands.Bot(
    command_prefix="v!",
    intents=intents,
    help_command=None
)

# ⏱️ uptime
bot.start_time = time.time()

# 🚀 evento ready
@bot.event
async def on_ready():
    print(f"✅ Logado como {bot.user}")
    print(f"📦 Cogs carregadas: {len(bot.cogs)}")

    try:
        synced = await bot.tree.sync()
        print(f"🌐 Slash sincronizados: {len(synced)}")
    except Exception as e:
        print(f"❌ Erro ao sincronizar slash: {e}")

# 💀 erro global (debug)
@bot.tree.error
async def on_app_command_error(interaction, error):
    print(f"❌ Slash erro: {error}")

# 📂 carregar TODAS as cogs (inclusive subpastas)
async def load_cogs():
    for root, dirs, files in os.walk("cogs"):
        for file in files:
            if file.endswith(".py") and file != "__init__.py":

                path = os.path.join(root, file)

                # 🔥 caminho limpo
                module = path.replace(os.sep, ".")[:-3]

                try:
                    await bot.load_extension(module)
                    print(f"✅ {module} carregado")
                except Exception as e:
                    print(f"❌ {module}: {e}")

# 🚀 start
async def main():
    async with bot:
        await load_cogs()
        await bot.start(TOKEN)

# 🔥 rodar
asyncio.run(main())